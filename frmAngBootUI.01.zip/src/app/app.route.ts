import { RouterModule, Routes } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { LoginComponent } from './login/login.component'
import { LoginLayoutComponent } from './layout/login-layout/login-layout.component';
import { MasterLayoutComponent } from './layout/master-layout/master-layout.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LogoutComponent } from './logout/logout.component';
import { UsersComponent } from './users/users.component';
import { AuthGuard } from './_guards/auth.guard';
import { RandomGuard } from './_guards/random.guard';

export const AppRoutes: Routes = [
  {
    path: '',
    component: LoginLayoutComponent,
    children: [
      { path: '', component: LoginComponent, pathMatch: 'full' },
      { path: 'login', component: LoginComponent },
    ], 
    canActivate: [AuthGuard]
  },
  {
    path: '',
    component: MasterLayoutComponent,
    children: [
      { path: 'dashboard', component: DashboardComponent, pathMatch: 'full' },
      { path: 'users', component: UsersComponent },
      { path: 'logout', component: LogoutComponent } 
    ], 
    canActivate: [RandomGuard], canLoad: [RandomGuard]
  },
  { path: '**', redirectTo: '' }
];

export const routing: ModuleWithProviders = RouterModule.forRoot(AppRoutes, { onSameUrlNavigation: 'reload' });