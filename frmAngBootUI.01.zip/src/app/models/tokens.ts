export class Tokens {
    jwt: string;
    refreshToken: string;
  }
  