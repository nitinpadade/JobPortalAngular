export class RefreshLogin {
    userId: number;
  }
  