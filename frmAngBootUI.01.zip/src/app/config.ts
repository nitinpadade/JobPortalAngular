export const config = {
    authUrl: 'https://localhost:44386/api/auth',
    resURL: 'https://localhost:44343/api'
  };
  