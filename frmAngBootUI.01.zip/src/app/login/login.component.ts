import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationService } from '../_services/authentication-service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  message: string;
  returnUrl: string;
  submitted = false;
  cookieValue:string;
  

  constructor(private authService: AuthenticationService, private formBuilder: FormBuilder,
    private router: Router) { }

    ngOnInit() {
      this.loginForm = this.formBuilder.group({
        UserName: ['', Validators.required],
        Password: ['', Validators.required]
      });
      this.returnUrl = '/dashboard';
      //this.authService.logout();
    }

    // convenience getter for easy access to form fields
    get f() { return this.loginForm.controls; }
    
    login() {
  
      this.submitted = true;
  
      // stop here if form is invalid
      if (this.loginForm.invalid) {
          return;
      }
      else{        
       
        this.authService.login(
          {
            username: this.f.UserName.value,
            password: this.f.Password.value
          }
        )
        .subscribe(success => {
          if (success) {
            this.router.navigate([this.returnUrl]);
          }          
        });        
      }    
    }

    

}
