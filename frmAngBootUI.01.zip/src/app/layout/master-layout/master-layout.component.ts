import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from 'src/app/_services/authentication-service';

@Component({
  selector: 'app-master-layout',
  templateUrl: './master-layout.component.html',
  styleUrls: ['./master-layout.component.css']
})
export class MasterLayoutComponent implements OnInit {

  constructor(private authService: AuthenticationService) { }

  ngOnInit() {
    this.loggedInUser=this.authService.getLoggedInUser();
  }

  navbarOpen = false;
   loggedInUser: string;

  toggleNavbar() {
    this.navbarOpen = !this.navbarOpen;
    
  }

}
