import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { of, Observable, throwError } from 'rxjs';
import { catchError, mapTo, tap } from 'rxjs/operators';
import { RefreshLogin } from '../models/RefreshLogin';
import { config } from '../config';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  private readonly JWT_TOKEN = 'JWT_TOKEN';
  private readonly REFRESH_TOKEN = 'REFRESH_TOKEN';
  private readonly User = 'User';
  private readonly UserId = 'UserId';
  private readonly RoleId = 'RoleId';

  refreshModel: RefreshLogin = new RefreshLogin();

  constructor(private http: HttpClient) { }

  authURL = config.authUrl + "/login";
  refreshUrl = config.authUrl + "/refresh";

  login(user: { username: string, password: string }): Observable<boolean> {
    return this.http.post<any>(this.authURL, user)
      .pipe(
        tap(tokens => this.doLoginUser(tokens)),
        mapTo(true),
        catchError(error => {
          return of(error);
          //return throwError({ status: 401, error: { message: 'Unauthorised' } });
        }));
  }

  private doLoginUser(tokens: any) {
    if (tokens == null)
    {
      alert("Invalid Username or Password");
    }
    else
      this.storeTokens(tokens);
  }

  private storeTokens(tokens: any) {
    console.log(tokens);
    localStorage.setItem(this.JWT_TOKEN, tokens.token);
    localStorage.setItem(this.REFRESH_TOKEN, tokens.token);
    localStorage.setItem(this.User, tokens.user);
    localStorage.setItem(this.UserId, tokens.userId);
    localStorage.setItem(this.RoleId, tokens.roleId);
  }

  private removeTokens() {
    localStorage.removeItem(this.JWT_TOKEN);
    localStorage.removeItem(this.REFRESH_TOKEN);
    localStorage.removeItem(this.User);
    localStorage.removeItem(this.UserId);
    localStorage.removeItem(this.RoleId);
  }

  isLoggedIn() {
    return !!this.getJwtToken();
  }

  getJwtToken() {
    //console.log(this.JWT_TOKEN);
    return localStorage.getItem(this.JWT_TOKEN);
  }

  getLoggedInUser() {
    return localStorage.getItem(this.User);
  }

  refreshToken() {
    return this.http.post<any>(this.refreshUrl, {
      'refreshLogin': this.getRefreshToken()
    }).pipe(tap((tokens: any) => {
      this.storeJwtToken(tokens.token);
    }), catchError(error => {
      //alert(error);
      return of(error);
      //return throwError({ status: 401, error: { message: 'Unauthorised' } });
    }));
  }

  private storeJwtToken(jwt: string) {
    localStorage.setItem(this.JWT_TOKEN, jwt);
  }

  isRequest() {
    if (localStorage.getItem(this.User) !== null)
      return localStorage.getItem(this.User);
    else
      return "";
  }


  private getRefreshToken() {
    this.refreshModel.userId = Number(localStorage.getItem(this.UserId));
  }

  logout() {
    this.doLogoutUser();
    return of(false);
  }

  private doLogoutUser() {
    this.removeTokens();
  }
}
