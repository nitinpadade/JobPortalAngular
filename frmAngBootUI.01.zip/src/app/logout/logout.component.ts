import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../_services/authentication-service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {

  returnUrl = '/login';

  constructor(private authService: AuthenticationService, private router: Router) { } 
  

  ngOnInit() {
   this.authService.logout();
   this.router.navigate([this.returnUrl]);
  }

}
