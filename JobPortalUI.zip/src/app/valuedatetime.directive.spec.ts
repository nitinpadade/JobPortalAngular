import { ValuedatetimeDirective } from './valuedatetime.directive';

describe('ValuedatetimeDirective', () => {
  it('should create an instance', () => {
    const directive = new ValuedatetimeDirective();
    expect(directive).toBeTruthy();
  });
});
