import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ModuleWithProviders  } from '@angular/core';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { LoginLayoutComponent } from './shared/login-layout/login-layout.component';
import { routing } from './app.route';
import { HomeLayoutComponent } from './shared/home-layout/home-layout.component';
import { HomeComponent } from './home/home.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MenuComponent } from './menu/menu.component';
import { SidebarDirective } from './sidebar.directive';
import { LogoutComponent } from './logout/logout.component';
import { UserlistComponent } from './userlist/userlist.component';
import { AdduserComponent } from './adduser/adduser.component';
import { CookieService } from 'ngx-cookie-service';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { MatDatepickerModule, MatInputModule,MatNativeDateModule,DateAdapter } from '@angular/material';
import { MAT_DATE_LOCALE } from '@angular/material';
import { ValuedatetimeDirective } from './valuedatetime.directive';
import { DatechangecompComponent } from './datechangecomp/datechangecomp.component';

const rootRouting: ModuleWithProviders = RouterModule.forRoot([], { useHash: true });


 
@NgModule({
  declarations: [ 
    AppComponent,
    LoginComponent,
    LoginLayoutComponent,
    HomeLayoutComponent,
    HomeComponent,
    DashboardComponent,
    MenuComponent,
    SidebarDirective,
    LogoutComponent,
    UserlistComponent,
    AdduserComponent,
    ValuedatetimeDirective,
    DatechangecompComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
    BrowserAnimationsModule,
    MatDatepickerModule, MatInputModule,MatNativeDateModule,
    HttpClientModule,
    routing   
  ],
  exports: [
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [CookieService,  
    { provide: MAT_DATE_LOCALE, useValue: 'en-GB'}
   // { provide: DateAdapter, useClass: CustomDateAdapter }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
  