export class Login {
    userid: string;
    password: string;
}
 