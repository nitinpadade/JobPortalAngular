export class UserListModel {
    Id: number;
    FirstName: string;
    LastName: string;
    MiddleName: string;
    Email: string;
    Mobile: string;
    UserName: string;
    Password: string;
    RoleId: number;
    DateOfBirth: string;
}
