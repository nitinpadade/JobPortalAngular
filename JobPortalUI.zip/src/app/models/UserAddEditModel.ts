export class UserAddEditModel {
    id: number;
    firstName: string;
    lastName: string;
    middleName: string;
    email: string;
    mobile: string;
    userName: string;
    password: string;
    roleId: number;
    dateOfBirth: Date;
}
