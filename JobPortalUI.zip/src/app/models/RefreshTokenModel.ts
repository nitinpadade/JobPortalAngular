export class RefreshTokenModel {
    Id: number;
}
