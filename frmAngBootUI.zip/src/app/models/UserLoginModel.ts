export class UserLoginModel {
    UserName: string;
    Password: string;
}
